<!--footer-->
    <div class="footer">
       <p>&copy; Men's Salon Management System Admin Panel.</p>
    </div>
        <!--//footer-->